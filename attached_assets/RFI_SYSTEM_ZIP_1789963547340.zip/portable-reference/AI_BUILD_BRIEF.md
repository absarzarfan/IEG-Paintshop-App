# AI Build Brief

Use this brief as the starting instruction for an AI coding assistant when creating a
new project from this reference package.

## Prompt

Build a production-ready workflow application for **[NEW PRODUCT NAME]**.

The application supports **[DESCRIBE THE NEW BUSINESS FUNCTION]** across these
departments:

- **[DEPARTMENT 1]**
- **[DEPARTMENT 2]**
- **[DEPARTMENT 3]**

Use the portable reference package as a behavioral starting point, but do not copy its
RFI branding, department names, seed users, deployment settings, credentials, or
environment-specific values.

## Required roles

Adapt the workflow to these roles:

- **Admin:** configure users, departments, work types, groups, shifts, and workflow
  options; view and manage all work.
- **Requestor:** create requests, attach files, monitor owned requests, add notes, and
  resubmit rejected work.
- **Inspector / Operator:** receive queued work, start and pause work, hand over work,
  record results, and complete or reject it.
- **Reviewer:** inspect completed work when the configured process requires a review
  gate.

Rename or split these roles if the new business needs different responsibilities.
Define every permission explicitly; do not infer access from UI visibility alone.

## Required behavior

Implement and test:

1. create → queue → start → pause/resume/handover → complete;
2. role-aware queues and ownership checks;
3. server-authoritative elapsed-time tracking;
4. single active inspection per inspector;
5. rejection, rework history, and resubmission without losing identity or history;
6. attachment authorization, file limits, and safe metadata handling;
7. comments and notes with actor and timestamp;
8. configurable review gates;
9. operational dashboards and reports using the business timezone;
10. persistence that works across application instances.

## Material and nesting boundary

Do not assume that the source project contains a production material planner or nesting
optimizer. Before implementing material planning, obtain approved rules for:

- material dimensions, thickness, grain, and rotation;
- trim margins and kerf;
- remnant eligibility;
- part quantities and split rules;
- sheet ordering and optimization goals;
- the 3-sheet versus 2-sheet correction formula;
- expected results for known-good examples.

The included `source/frontend/nesting.ts` is a deterministic rectangle-packing
reference only. It is not an optimal solver and must not be presented as historical
business logic.

## Implementation guidance

- Start from `source/shared/types.ts` and adapt the domain entities.
- Keep workflow transitions pure and testable.
- Adapt `source/backend/timeAndShift.ts` to the new business timezone and shifts.
- Use `contracts/openapi.yaml` as a contract starting point, then regenerate clients
  only inside the new project.
- Choose the normalized schema in `database/002_normalized_workflow.sql` unless the
  new project has a documented reason to use a JSONB snapshot.
- Keep legacy compatibility code isolated from new domain logic.
- Never include passwords, tokens, bucket IDs, deployment URLs, `.env` files, generated
  output, or runtime data in the new project.

## Definition of done

The new project is ready only when:

- all adapted roles and transitions have automated tests;
- rejected and resubmitted work preserves the required history;
- authorization is enforced server-side;
- report dates and shift windows use the approved business timezone;
- attachment and upload paths are bounded and observable;
- material and nesting behavior has owner-approved rules and acceptance fixtures;
- the application passes type checking, API contract validation, database checks, and
  a mobile browser regression test for login and the first authenticated request.