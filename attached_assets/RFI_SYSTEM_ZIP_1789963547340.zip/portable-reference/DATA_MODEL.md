# Data Model

## Core entities

### User

```text
id                 integer
username           string
role               Admin | Requestor | QC Inspector | PDI | Reviewer
department         string | null
active             boolean
clockedInAt        timestamp | null
lastActivityAt     timestamp | null
activeShiftKey     string | null
```

Do not persist plaintext passwords in a production port. The source fixture uses a
simple local representation, but a new project should use a real password hash or an
approved identity provider.

### WorkRequest

```text
id                 integer
requestorId        integer | null
requestorName      string
group              string
department         string
jobNo              string
serialOrReference  string
location           string
workType           string | null
status             RequestStatus
submittedAt        timestamp
startedAt          timestamp | null
completedAt        timestamp | null
assignedTo         string | null
inspectorId        integer | null
inspectorName      string | null
elapsedMinutes     integer
pausedAt           timestamp | null
result             Pass | Reject | null
remark             string
requestorRemark    string
reworkCount        integer
reviewStatus       Not required | Pending | Approved | Rejected
reviewedAt         timestamp | null
reviewedBy         string | null
reviewerComment    string
```

### InspectionSession

```text
id                 integer
inspectorId        integer
inspectorName      string
startedAt          timestamp
endedAt            timestamp | null
elapsedMinutes     integer
status             Active | Completed | Handover
```

There may be many sessions per work request but at most one active session.

### InspectionNote

```text
id                 integer
cycle              integer
note               string
authorName         string
authorRole         string
createdAt          timestamp
attachments        Attachment[]
```

### Comment

```text
id                 integer
authorName         string
authorRole         string
body               string
createdAt          timestamp
```

### Attachment

```text
id                 integer | optional
objectPath         string
name               string
mimeType            string
size                integer
createdAt          timestamp | optional
```

`objectPath` is a private object-storage reference, not a public credential or
long-lived signed URL.

### Department, Group, WorkTypeAccess

Department and group are configurable registries. Work type access may be constrained
by role and/or department:

```text
WorkTypeAccess {
  workType: string
  roles: Role[] | null
  departments: string[] | null
}
```

Null means unrestricted for that dimension.

## State invariants

1. `Completed` has `completedAt` and no active session.
2. `In progress` has an assignment and one active session.
3. `Queued` and `Ready for handover` have no active session.
4. `Rejected` has a rejection reason and `reworkCount >= 1`.
5. `reworkCount` never decreases.
6. resubmission does not create a new identity row.
7. elapsed minutes is monotonic for a request.
8. historical rows continue to reference their original department/work type even if
   the registry entry is deleted.

## Material extension entities

These are **not in the source project**; they are a suggested extension for a new
material/planning function:

```text
Material(id, code, description, grade, thickness, unit)
StockSheet(id, materialId, width, height, availableQty, lot, status)
PartLine(id, requestId, partNo, materialId, width, height, quantity, grain, rotationPolicy)
NestPlan(id, requestId, materialId, algorithmVersion, rawSheetCount, correctedSheetCount)
NestPlacement(id, nestPlanId, partLineId, sheetIndex, x, y, width, height, rotated)
```

`correctedSheetCount` must be nullable until an approved domain correction exists.

## API operations

The example contract covers:

- `POST /workflow/login`
- `GET /workflow/dashboard`
- `GET/POST /workflow/jobs`
- `GET /workflow/jobs/{id}`
- `POST /workflow/jobs/{id}/timer`
- `POST /workflow/jobs/{id}/complete`
- `POST /workflow/jobs/{id}/resubmit`
- `POST /workflow/jobs/{id}/comments`
- `POST /workflow/jobs/{id}/review`
- `POST /workflow/jobs/{id}/attachments/upload-url`

The names are intentionally generic. Adapt route prefix, auth, and terminology.