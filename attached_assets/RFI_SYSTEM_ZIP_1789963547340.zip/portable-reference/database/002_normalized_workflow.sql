-- REFERENCE normalized schema for a new project.
-- No credentials or environment-specific values are included.

CREATE TABLE IF NOT EXISTS workflow_users (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL,
  department TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  clocked_in_at TIMESTAMPTZ,
  last_activity_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_jobs (
  id BIGSERIAL PRIMARY KEY,
  requestor_id BIGINT REFERENCES workflow_users(id),
  requestor_name TEXT NOT NULL,
  group_name TEXT NOT NULL,
  department TEXT NOT NULL,
  job_no TEXT NOT NULL,
  serial_or_reference TEXT NOT NULL,
  location TEXT NOT NULL,
  work_type TEXT,
  status TEXT NOT NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  assigned_to TEXT,
  inspector_id BIGINT REFERENCES workflow_users(id),
  inspector_name TEXT,
  elapsed_minutes INTEGER NOT NULL DEFAULT 0 CHECK (elapsed_minutes >= 0),
  paused_at TIMESTAMPTZ,
  result TEXT,
  remark TEXT NOT NULL DEFAULT '',
  requestor_remark TEXT NOT NULL DEFAULT '',
  rework_count INTEGER NOT NULL DEFAULT 0 CHECK (rework_count >= 0),
  review_status TEXT NOT NULL DEFAULT 'Not required',
  reviewed_at TIMESTAMPTZ,
  reviewed_by TEXT,
  reviewer_comment TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_inspection_sessions (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES workflow_jobs(id) ON DELETE CASCADE,
  inspector_id BIGINT NOT NULL REFERENCES workflow_users(id),
  inspector_name TEXT NOT NULL,
  started_at TIMESTAMPTZ NOT NULL,
  ended_at TIMESTAMPTZ,
  elapsed_minutes INTEGER NOT NULL DEFAULT 0 CHECK (elapsed_minutes >= 0),
  status TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS one_active_session_per_job
  ON workflow_inspection_sessions(job_id)
  WHERE status = 'Active' AND ended_at IS NULL;

CREATE TABLE IF NOT EXISTS workflow_attachments (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES workflow_jobs(id) ON DELETE CASCADE,
  collection TEXT NOT NULL,
  object_path TEXT NOT NULL,
  name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL CHECK (size_bytes >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_notes (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES workflow_jobs(id) ON DELETE CASCADE,
  cycle INTEGER NOT NULL DEFAULT 0 CHECK (cycle >= 0),
  note TEXT NOT NULL,
  author_name TEXT NOT NULL,
  author_role TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workflow_comments (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT NOT NULL REFERENCES workflow_jobs(id) ON DELETE CASCADE,
  author_name TEXT NOT NULL,
  author_role TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS workflow_jobs_queue_idx
  ON workflow_jobs(status, department, submitted_at);
CREATE INDEX IF NOT EXISTS workflow_jobs_requestor_idx
  ON workflow_jobs(requestor_id, submitted_at);