-- REFERENCE: compact persistence used by the source project.
-- ADAPT: replace the JSONB payload with normalized tables when concurrent writes,
-- audit queries, or material planning require relational access.
CREATE TABLE IF NOT EXISTS rfi_state (
  id INTEGER PRIMARY KEY,
  payload JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);