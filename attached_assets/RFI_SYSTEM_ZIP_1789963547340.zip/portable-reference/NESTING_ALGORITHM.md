# Nesting and Cutting Algorithm

## Provenance warning

There is no production nesting/cutting implementation in the source RFI project.
Searches found no verified part-list planner, sheet optimizer, kerf model, remnant
model, or 3-sheet/2-sheet correction. Therefore this document has two separate parts:

1. the **source-project conclusion**: no nesting rule can be ported from the source;
2. a **generic reference implementation** in `source/frontend/nesting.ts` that is safe
   and deterministic but is not claimed to be optimal or historically correct.

Do not use the generic implementation as a substitute for domain validation.

## Reference problem definition

Input:

- rectangular sheet width and height;
- non-negative kerf/gap between neighboring parts;
- part rectangles with quantity;
- optional 90-degree rotation.

Output:

- sheet index for every part instance;
- `x`, `y`, `width`, `height`, and rotation flag;
- raw sheet count;
- used area and utilization;
- unplaced parts, if any.

Coordinates use the top-left corner of a sheet. Width and height use one consistent
unit, normally millimeters. The implementation rejects non-positive dimensions,
negative quantities, and non-finite numbers.

## Algorithm

The reference algorithm is a deterministic shelf packer:

1. expand each part quantity into numbered instances;
2. sort instances by descending area, then descending max dimension, then stable ID;
3. try existing rows on each existing sheet;
4. for each candidate row, try the original orientation and, if allowed, a rotated
   orientation;
5. choose the candidate that leaves the least horizontal remainder, with stable
   tie-breakers;
6. if no row fits, create a new row on the first sheet where the part fits;
7. if no sheet fits, create a new sheet;
8. report utilization from actual placed area divided by total sheet area.

Rows are separated by `kerf`. Parts in the same row are also separated by `kerf`.
The implementation never places a rectangle outside a sheet and never overlaps two
placed rectangles.

This is a feasible-layout heuristic. It does **not** guarantee:

- minimum sheet count;
- minimum cutting path;
- grain-direction compliance;
- guillotine-cut feasibility;
- saw sequencing;
- common-line cutting;
- remnant reuse;
- material grade or heat-lot constraints.

## 3-sheet vs 2-sheet correction

No such correction exists in the source project. The package intentionally does not
invent a correction factor or silently adjust the computed sheet count.

If the new business has a validated correction, add it as an explicit policy after
the raw geometry result:

```text
rawSheetCount = geometric nesting result
correctedSheetCount = domain correction(raw result, stock policy, order context)
```

The correction must be specified by:

- exact formula or decision table;
- why it applies;
- whether it changes physical count, planning allowance, or costing only;
- examples for 2-sheet, 3-sheet, and boundary cases;
- acceptance tests signed off by the process owner.

Never implement “if 3 then 2” or similar logic without this evidence. A planning
allowance must not corrupt the physical cutting plan.

## Porting to a real material function

Before using `nesting.ts`, define:

- material code, thickness, grade, and grain direction;
- usable sheet dimensions and edge trim;
- kerf and minimum gap;
- rotation and mirroring rules;
- part keep-out zones and holes;
- remnant eligibility and inventory ownership;
- whether quantity is gross, net, or already scrap-adjusted;
- whether the output is an estimate, a production cut plan, or a costing input.

Then replace the heuristic with the approved algorithm if those requirements exceed
the rectangle/shelf model.