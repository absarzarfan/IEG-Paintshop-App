# Source Provenance

## Extracted from the source project

- request lifecycle: `Queued`, `Ready for handover`, `In progress`, `Paused`,
  `Pending review`, `Completed`, `Rejected`;
- roles: Admin, Requestor, QC Inspector, PDI, Reviewer;
- timer sessions, pause/resume/handover, cumulative elapsed minutes;
- QC Pass / Reject, rework notes, reviewer decisions;
- requestor ownership normalization for legacy records;
- attachment rules and private object-storage pattern;
- Asia/Bangkok reporting calendar;
- JSONB state persistence and the normalized schema recommendation.

## Authored as portable reference

- generic names in `source/shared/types.ts`;
- pure policy implementation in `source/backend/workflowPolicy.ts`;
- generic part-list validation in `source/backend/partList.ts`;
- deterministic rectangle shelf nesting in `source/frontend/nesting.ts`;
- the normalized SQL schema and generic OpenAPI example.

The authored modules are intentionally small and dependency-free. They are intended to
make the boundary between product policy and application wiring explicit.