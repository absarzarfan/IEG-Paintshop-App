# Porting Checklist

## A. Domain discovery

- [ ] Write the new product/function name and one-sentence purpose.
- [ ] List every department, work center, queue, and responsibility.
- [ ] Decide which source roles map to the new roles.
- [ ] Define the new request identity fields.
- [ ] Define the exact meaning of `Pass`, `Reject`, `Completed`, and `Pending review`.
- [ ] Confirm whether PDI/reviewer gates exist.
- [ ] Obtain material/planning rules from the process owner; do not infer them.
- [ ] Obtain approved examples for any sheet-count correction.

## B. Copy directly

- [ ] Start from `source/shared/types.ts`.
- [ ] Copy pure identity normalization and request ownership behavior.
- [ ] Copy timer session accumulation and single-active-session invariant.
- [ ] Copy attachment validation only if limits are still 10 files / 10 MB.
- [ ] Copy the API error shape and explicit authorization checks.
- [ ] Copy tests for monotonic elapsed time and rework history.

## C. Adapt

- [ ] Rename request/job/RFI terms everywhere.
- [ ] Replace departments, groups, work types, and role names.
- [ ] Replace route prefix and generated client wiring.
- [ ] Replace local auth/session implementation with approved auth.
- [ ] Replace plaintext fixture password handling with hashed credentials or IdP.
- [ ] Choose database persistence strategy.
- [ ] Set business timezone and shift calendar.
- [ ] Set attachment types, limits, compression policy, and retention.
- [ ] Configure object storage through environment/secrets tooling.
- [ ] Define report periods and KPI formulas.
- [ ] Add material, stock, part, and nesting entities if required.

## D. API and database

- [ ] Import `contracts/openapi.yaml` only after replacing generic names.
- [ ] Validate all request and response schemas at route boundaries.
- [ ] Use `database/002_normalized_workflow.sql` for a new normalized system unless
      a documented reason requires JSONB state.
- [ ] Add unique/idempotency rules for uploads and request submission.
- [ ] Add indexes for queue status, department, assignment, submitted time, and
      active sessions.
- [ ] Ensure deleted registry values remain readable in historical records.

## E. Nesting/material acceptance

- [ ] Confirm units and numeric precision.
- [ ] Confirm sheet usable area after trim.
- [ ] Confirm kerf, gap, grain, rotation, and mirroring.
- [ ] Confirm whether a result is estimate, planning, costing, or production.
- [ ] Add overlap and boundary tests.
- [ ] Add known-good examples with expected sheet count.
- [ ] Add 2-sheet and 3-sheet boundary examples.
- [ ] Document any correction as a versioned policy, not a hidden constant.

## F. Security and quality

- [ ] Remove all credentials, data files, deployment URLs, and environment values.
- [ ] Never expose storage credentials to the browser.
- [ ] Enforce ownership and role checks on the server.
- [ ] Use no-store for live polling where stale responses are harmful.
- [ ] Add audit events for result, review, rework, and admin closure.
- [ ] Run typecheck, unit tests, API contract validation, and browser regression.
- [ ] Verify cleanup of test jobs and temporary attachments.