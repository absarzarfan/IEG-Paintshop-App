# Business Rules

## 1. Workflow lifecycle

### Canonical statuses

| Status | Meaning | Typical owner |
|---|---|---|
| `Queued` | Submitted and waiting for work | Requestor / queue |
| `Ready for handover` | Previous inspector stopped and made work available | QC/PDI queue |
| `In progress` | One inspector owns an active inspection session | Assigned inspector |
| `Paused` | Assigned inspector paused without closing the job | Assigned inspector |
| `Pending review` | QC completed and a final reviewer decision is required | Reviewer |
| `Completed` | Work is closed successfully | System / reviewer |
| `Rejected` | Inspection or final review failed and needs rework | Requestor / queue |

**ADAPT:** rename statuses only if the new project still preserves the same state
semantics. Do not combine `Paused` and `Ready for handover`; they have different
ownership meaning.

## 2. Roles and access

- **Admin**: manage users, groups, departments, work types, access scopes, and
  administrator completion/closure.
- **Requestor**: create requests, inspect read-only progress, add requestor remarks,
  and resubmit own rejected requests.
- **QC Inspector**: start, pause, resume, hand over, inspect, and record Pass/Reject.
- **PDI**: follows the same operational inspector boundaries as QC where the new process
  needs PDI work.
- **Reviewer**: use the operational/review portal, add comments, and make final review
  decisions; reviewer accounts do not perform normal timer mutations.

`Guest` is normalized to `Reviewer` for legacy data. **VERIFY** whether the new system
needs this compatibility alias.

## 3. Request creation

- A new request starts in `Queued`.
- Required business identity is preserved: requestor, job/order number, serial or
  reference number, location, function/department, and work type.
- Department and work type must come from configured values.
- Work type may be scoped by role and department.
- Historical records are not rewritten when an option is renamed or removed; deleted
  options disappear from future selection only.

## 4. Inspector ownership and timer

- Only a clocked-in, active inspector can start an inspection.
- Only the assigned inspector can pause, resume, hand over, stop, or record the outcome.
- A request cannot have two active inspection sessions.
- Every active session has `startedAt`, `endedAt`, status, inspector identity, and
  elapsed minutes.
- Total elapsed time is cumulative across all completed sessions plus the current
  active session. It must never decrease when a job is paused, handed over, rejected,
  or resubmitted.
- A handover closes the current session as `Handover`, clears the assignment, and
  changes the job to `Ready for handover`.
- A normal stop without a QC result is treated as a successful close only if the
  product explicitly allows administrator/operational closure.

## 5. QC result and review

- QC `Pass` closes the job as `Completed` when no final review gate is configured.
- QC `Reject` changes the job to `Rejected`, increments `reworkCount`, and appends an
  inspection note containing the rejection reason and attachments.
- If a final review gate is configured, QC pass may instead create `Pending review`;
  the reviewer then chooses `Approved` → `Completed` or `Rejected` → `Rejected`.
- A rejection decision requires a non-blank reason/comment.
- Reviewer comments and decisions are append-only history; do not silently overwrite
  earlier notes.

## 6. Resubmission

Only the original requestor or an Admin may resubmit a rejected request.

Resubmission:

1. preserves the original request identity;
2. preserves existing requestor notes and attachments;
3. preserves inspection history;
4. preserves cumulative `reworkCount`;
5. resets current assignment, active timer, result, review decision, and inspection
   output;
6. updates the submission timestamp;
7. changes the status to `Queued`;
8. appends a new resubmission note when a remark or attachment is provided.

## 7. Session and idle rules

- Session authentication is server-authoritative.
- A 30-minute inactivity timeout applies to user sessions in the source project.
- QC/PDI presence is also bounded by clock-in/shift rules.
- The client timer is only a display/heartbeat companion; it is not the authority.
- An inspector with an active job remains `Working` even after the nominal shift ends.
- `On Break` is displayed as `Idling` in the operational UI.
- Online time outside an inspection can be included in idle/working KPI calculations
  according to the configured report definition.

**ADAPT:** timeout duration, shift boundaries, breaks, and status labels.

## 8. Attachments

- Maximum 10 attachments per request in the source policy.
- Maximum 10 MB per attachment.
- JPEG, PNG, and WebP are compressed before upload; PDF is not compressed.
- Upload authorization is requested from the backend; the browser does not receive
  storage credentials.
- Legacy inline data URLs must not be copied into the shared state snapshot; migrate
  them to object storage or keep them outside metadata reads.

## 9. Reporting

- Operational periods and weekday labels use `Asia/Bangkok` in the source project.
- Report queries must receive explicit date-only boundaries and must not depend on the
  server machine timezone.
- Live polling responses should use `no-store`/`no-cache` semantics so a browser does
  not receive stale 304 data.
- KPI coverage includes both QC Inspector and PDI accounts.

## 10. Material/planning boundary

This source project contains no verified material consumption, BOM, stock reservation,
sheet yield, cutting kerf, remnant, or nesting business rule. These must be discovered
from the new function's process owner and added as new policy, not inferred from this
package.