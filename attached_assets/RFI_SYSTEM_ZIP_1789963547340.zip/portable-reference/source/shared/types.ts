export type Role = "Admin" | "Requestor" | "QC Inspector" | "PDI" | "Reviewer";

export type RequestStatus =
  | "Queued"
  | "Ready for handover"
  | "In progress"
  | "Paused"
  | "Pending review"
  | "Completed"
  | "Rejected";

export type ReviewStatus = "Not required" | "Pending" | "Approved" | "Rejected";
export type Result = "Pass" | "Reject";
export type SessionStatus = "Active" | "Completed" | "Handover";

export interface Attachment {
  objectPath: string;
  name: string;
  mimeType: string;
  size: number;
}

export interface InspectionSession {
  id: number;
  inspectorId: number;
  inspectorName: string;
  startedAt: string;
  endedAt: string | null;
  elapsedMinutes: number;
  status: SessionStatus;
}

export interface InspectionNote {
  id: number;
  cycle: number;
  note: string;
  authorName: string;
  authorRole: Role;
  createdAt: string;
  attachments: Attachment[];
}

export interface WorkComment {
  id: number;
  authorName: string;
  authorRole: Role;
  body: string;
  createdAt: string;
}

export interface WorkRequest {
  id: number;
  requestorId: number | null;
  requestorName: string;
  group: string;
  department: string;
  jobNo: string;
  serialOrReference: string;
  location: string;
  workType: string | null;
  status: RequestStatus;
  submittedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  assignedTo: string | null;
  inspectorId: number | null;
  inspectorName: string | null;
  elapsedMinutes: number;
  pausedAt: string | null;
  result: Result | null;
  remark: string;
  requestorRemark: string;
  attachments: Attachment[];
  inspectionAttachments: Attachment[];
  inspectionSessions: InspectionSession[];
  inspectionNotes: InspectionNote[];
  comments: WorkComment[];
  reworkCount: number;
  reviewStatus: ReviewStatus;
  reviewedAt: string | null;
  reviewedBy: string | null;
  reviewerComment: string;
}

export interface Actor {
  id: number;
  username: string;
  role: Role;
  active: boolean;
  clockedIn: boolean;
}