export interface PartLineInput {
  partNo: string;
  materialCode: string;
  width: number;
  height: number;
  quantity: number;
  grain?: "length" | "width" | "none";
  allowRotation?: boolean;
}

export interface NormalizedPartLine extends PartLineInput {
  lineNo: number;
}

export interface PartListValidation {
  valid: boolean;
  errors: string[];
  lines: NormalizedPartLine[];
}

/**
 * Domain-neutral part-list normalization.
 * It validates geometry and quantity but intentionally does not calculate stock,
 * scrap, yield, or corrected sheet count.
 */
export function normalizePartList(input: PartLineInput[]): PartListValidation {
  const errors: string[] = [];
  const lines: NormalizedPartLine[] = [];
  const seenPartNumbers = new Set<string>();

  input.forEach((line, index) => {
    const partNo = line.partNo.trim();
    const materialCode = line.materialCode.trim();
    if (!partNo) errors.push(`line ${index + 1}: partNo is required`);
    if (!materialCode) errors.push(`line ${index + 1}: materialCode is required`);
    if (seenPartNumbers.has(partNo)) errors.push(`line ${index + 1}: duplicate partNo ${partNo}`);
    seenPartNumbers.add(partNo);
    if (!Number.isFinite(line.width) || line.width <= 0) errors.push(`line ${index + 1}: width must be positive`);
    if (!Number.isFinite(line.height) || line.height <= 0) errors.push(`line ${index + 1}: height must be positive`);
    if (!Number.isInteger(line.quantity) || line.quantity <= 0) errors.push(`line ${index + 1}: quantity must be a positive integer`);
    if (line.grain && !["length", "width", "none"].includes(line.grain)) {
      errors.push(`line ${index + 1}: unsupported grain value`);
    }
    lines.push({
      ...line,
      lineNo: index + 1,
      partNo,
      materialCode,
      allowRotation: line.allowRotation ?? true,
    });
  });
  return { valid: errors.length === 0, errors, lines };
}