export const BUSINESS_TIME_ZONE = "Asia/Bangkok";

export type ShiftType = "Shift 1" | "Shift 2" | "Shift 3";

export interface ShiftWindow {
  type: ShiftType;
  startAt: Date;
  endAt: Date;
  breaks: Array<{ startAt: Date; endAt: Date }>;
}

export function businessDay(value: string | Date, timeZone = BUSINESS_TIME_ZONE): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(value));
}

export function businessMinutes(value: Date, timeZone = BUSINESS_TIME_ZONE): number {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(value);
  const hour = Number(parts.find((part) => part.type === "hour")?.value ?? 0);
  const minute = Number(parts.find((part) => part.type === "minute")?.value ?? 0);
  return hour * 60 + minute;
}

export function shiftTypeForStart(value: Date, timeZone = BUSINESS_TIME_ZONE): ShiftType {
  const minutes = businessMinutes(value, timeZone);
  if (minutes >= 450 && minutes < 930) return "Shift 1";
  if (minutes >= 930 && minutes < 1410) return "Shift 2";
  return "Shift 3";
}

/**
 * Minimal shift window matching the source defaults.
 * ADAPT: replace hours/breaks with the new operation's approved calendar.
 */
export function shiftWindowForClockIn(
  clockInAt: Date,
  timeZone = BUSINESS_TIME_ZONE,
): ShiftWindow {
  const type = shiftTypeForStart(clockInAt, timeZone);
  const clockInMinutes = businessMinutes(clockInAt, timeZone);
  const isAfterMidnightOvernight = type === "Shift 3" && clockInMinutes < 450;
  const day = businessDay(
    isAfterMidnightOvernight
      ? new Date(clockInAt.getTime() - 24 * 60 * 60 * 1000)
      : clockInAt,
    timeZone,
  );
  const start = type === "Shift 1" ? "07:30" : type === "Shift 2" ? "15:30" : "23:30";
  const end = type === "Shift 1" ? "15:30" : type === "Shift 2" ? "23:30" : "07:30";
  const startAt = new Date(`${day}T${start}:00+07:00`);
  const nextDay = businessDay(new Date(startAt.getTime() + 24 * 60 * 60 * 1000), timeZone);
  const endAt = type === "Shift 3"
    ? new Date(`${nextDay}T${end}:00+07:00`)
    : new Date(`${day}T${end}:00+07:00`);
  const breaks = type === "Shift 1"
    ? [{ startAt: new Date(`${day}T12:00:00+07:00`), endAt: new Date(`${day}T13:00:00+07:00`) }]
    : type === "Shift 2"
      ? [
          { startAt: new Date(`${day}T16:45:00+07:00`), endAt: new Date(`${day}T17:00:00+07:00`) },
          { startAt: new Date(`${day}T18:30:00+07:00`), endAt: new Date(`${day}T19:15:00+07:00`) },
        ]
      : [];
  return { type, startAt, endAt, breaks };
}