export const MAX_ATTACHMENTS = 10;
export const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;

export const COMPRESSIBLE_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
]);

export interface UploadCandidate {
  name: string;
  mimeType: string;
  size: number;
}

export function validateAttachmentBatch(files: UploadCandidate[]): string[] {
  const errors: string[] = [];
  if (files.length > MAX_ATTACHMENTS) {
    errors.push(`A request may contain at most ${MAX_ATTACHMENTS} attachments`);
  }
  for (const file of files) {
    if (!Number.isInteger(file.size) || file.size < 0 || file.size > MAX_ATTACHMENT_BYTES) {
      errors.push(`${file.name}: attachment exceeds the ${MAX_ATTACHMENT_BYTES} byte limit`);
    }
    if (!file.name.trim() || !file.mimeType.trim()) {
      errors.push("Every attachment must have a name and MIME type");
    }
  }
  return errors;
}

export function shouldCompress(mimeType: string): boolean {
  return COMPRESSIBLE_MIME_TYPES.has(mimeType.toLowerCase());
}