import type {
  Actor,
  InspectionNote,
  InspectionSession,
  RequestStatus,
  Result,
  Role,
  WorkRequest,
} from "../shared/types";

export type TimerAction = "start" | "pause" | "resume" | "handover" | "stop";

export type PolicyResult =
  | { ok: true; value: WorkRequest }
  | { ok: false; status: 400 | 403 | 409; error: string };

export function normalizeRole(role: unknown): Role {
  if (role === "Guest") return "Reviewer";
  if (role === "Admin" || role === "Requestor" || role === "Reviewer" || role === "PDI") {
    return role;
  }
  return "QC Inspector";
}

export function normalizedIdentity(value: string | null | undefined): string {
  return String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

export function requestBelongsToRequestor(request: WorkRequest, actor: Actor): boolean {
  return request.requestorId === actor.id
    || normalizedIdentity(request.requestorName) === normalizedIdentity(actor.username);
}

export function elapsedAt(request: WorkRequest, now: Date): number {
  const completedMinutes = request.inspectionSessions.reduce(
    (total, session) => total + Math.max(0, session.elapsedMinutes),
    0,
  );
  const activeMinutes = request.inspectionSessions
    .filter((session) => session.status === "Active" && session.endedAt === null)
    .reduce((total, session) => {
      const startedAt = new Date(session.startedAt).getTime();
      return Number.isFinite(startedAt)
        ? total + Math.max(0, Math.floor((now.getTime() - startedAt) / 60_000))
        : total;
    }, 0);
  return Math.max(request.elapsedMinutes, completedMinutes + activeMinutes);
}

function activeSession(request: WorkRequest): InspectionSession | undefined {
  return request.inspectionSessions.find(
    (session) => session.status === "Active" && session.endedAt === null,
  );
}

function ensureActiveSession(request: WorkRequest, actor: Actor, now: Date): InspectionSession {
  const existing = activeSession(request);
  if (existing) return existing;

  const session: InspectionSession = {
    id: Math.max(0, ...request.inspectionSessions.map((item) => item.id)) + 1,
    inspectorId: actor.id,
    inspectorName: actor.username,
    startedAt: request.startedAt ?? now.toISOString(),
    endedAt: null,
    elapsedMinutes: request.inspectionSessions.length ? 0 : Math.max(0, request.elapsedMinutes),
    status: "Active",
  };
  request.inspectionSessions.push(session);
  return session;
}

function closeActiveSession(
  request: WorkRequest,
  now: Date,
  status: "Completed" | "Handover",
): void {
  const session = activeSession(request);
  if (session) {
    session.endedAt = now.toISOString();
    session.elapsedMinutes = Math.max(
      0,
      Math.floor((now.getTime() - new Date(session.startedAt).getTime()) / 60_000),
    );
    session.status = status;
  }
  request.elapsedMinutes = elapsedAt(request, now);
}

function failure(
  status: 400 | 403 | 409,
  error: string,
): PolicyResult {
  return { ok: false, status, error };
}

function isActiveInspector(actor: Actor): boolean {
  return actor.active && actor.clockedIn && (actor.role === "QC Inspector" || actor.role === "PDI" || actor.role === "Admin");
}

function isAssignedTo(request: WorkRequest, actor: Actor): boolean {
  return request.assignedTo === actor.username
    || request.inspectorId === actor.id
    || normalizedIdentity(request.inspectorName) === normalizedIdentity(actor.username);
}

/**
 * Pure state transition policy for timer actions.
 * The caller is responsible for authentication, persistence, audit logging, and
 * returning the response through its chosen web framework.
 */
export function applyTimerAction(
  input: WorkRequest,
  actor: Actor,
  action: TimerAction,
  now = new Date(),
): PolicyResult {
  const request = structuredClone(input) as WorkRequest;

  if (actor.role === "Reviewer") {
    return failure(403, "Reviewer accounts cannot perform timer mutations");
  }

  if (action === "start") {
    if (request.status !== "Queued" && request.status !== "Ready for handover") {
      return failure(400, "Only queued or handed-over requests can be started");
    }
    if (!isActiveInspector(actor)) {
      return failure(403, "Only a clocked-in inspector can start an inspection");
    }
    if (activeSession(request)) {
      return failure(409, "This inspection already has an active session");
    }
    request.status = "In progress";
    request.startedAt = now.toISOString();
    request.completedAt = null;
    request.pausedAt = null;
    request.assignedTo = actor.username;
    request.inspectorId = actor.id;
    request.inspectorName = actor.username;
    ensureActiveSession(request, actor, now);
    return { ok: true, value: request };
  }

  if (!isAssignedTo(request, actor)) {
    return failure(403, "Only the assigned inspector can change this inspection");
  }

  if (action === "pause") {
    if (request.status !== "In progress") {
      return failure(403, "Only an active inspection can be paused");
    }
    ensureActiveSession(request, actor, now);
    closeActiveSession(request, now, "Completed");
    request.status = "Paused";
    request.startedAt = null;
    request.pausedAt = now.toISOString();
    return { ok: true, value: request };
  }

  if (action === "resume") {
    if (request.status !== "Paused") {
      return failure(403, "Only a paused inspection can be resumed");
    }
    request.status = "In progress";
    request.startedAt = now.toISOString();
    request.pausedAt = null;
    ensureActiveSession(request, actor, now);
    return { ok: true, value: request };
  }

  if (action === "handover") {
    if (request.status !== "In progress") {
      return failure(403, "Only an active inspection can be handed over");
    }
    ensureActiveSession(request, actor, now);
    closeActiveSession(request, now, "Handover");
    request.status = "Ready for handover";
    request.startedAt = null;
    request.pausedAt = now.toISOString();
    request.assignedTo = null;
    request.inspectorId = null;
    request.inspectorName = null;
    return { ok: true, value: request };
  }

  if (request.status !== "In progress") {
    return failure(403, "Only an active inspection can be stopped");
  }
  ensureActiveSession(request, actor, now);
  closeActiveSession(request, now, "Completed");
  request.status = "Completed";
  request.completedAt = now.toISOString();
  request.pausedAt = null;
  request.result = "Pass";
  request.remark ||= "Completed and closed without a recorded QC result.";
  request.startedAt = null;
  request.assignedTo = null;
  request.inspectorId = null;
  request.inspectorName = null;
  return { ok: true, value: request };
}

export function completeInspection(
  input: WorkRequest,
  actor: Actor,
  result: Result,
  remark: string,
  inspectionAttachments: WorkRequest["inspectionAttachments"] = [],
  now = new Date(),
): PolicyResult {
  const request = structuredClone(input) as WorkRequest;
  if (request.status !== "In progress") {
    return failure(400, "Only active inspections can be completed");
  }
  if (!isActiveInspector(actor) || !isAssignedTo(request, actor)) {
    return failure(403, "Only the assigned active inspector can record an outcome");
  }

  const cleanRemark = remark.trim();
  ensureActiveSession(request, actor, now);
  closeActiveSession(request, now, "Completed");
  request.completedAt = now.toISOString();
  request.result = result;
  request.remark = cleanRemark;
  request.inspectionAttachments = inspectionAttachments;
  request.status = result === "Pass" ? "Completed" : "Rejected";
  request.startedAt = null;
  request.pausedAt = null;
  request.assignedTo = null;
  request.inspectorId = null;
  request.inspectorName = null;
  request.reviewStatus = "Not required";
  request.reviewedAt = null;
  request.reviewedBy = null;
  request.reviewerComment = "";

  if (result === "Reject") {
    request.reworkCount += 1;
    const note: InspectionNote = {
      id: Math.max(0, ...request.inspectionNotes.map((item) => item.id)) + 1,
      cycle: request.reworkCount,
      note: cleanRemark || "Inspection rejected and rework requested.",
      authorName: actor.username,
      authorRole: normalizeRole(actor.role),
      createdAt: now.toISOString(),
      attachments: inspectionAttachments,
    };
    request.inspectionNotes.push(note);
  }
  return { ok: true, value: request };
}

export function canMutate(actor: Actor): boolean {
  return actor.role !== "Reviewer";
}

export function allowedStatusesForQueue(): RequestStatus[] {
  return ["Queued", "Ready for handover", "Paused", "Rejected"];
}