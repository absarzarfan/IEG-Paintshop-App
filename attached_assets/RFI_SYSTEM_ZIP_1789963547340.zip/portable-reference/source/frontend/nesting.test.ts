import { strict as assert } from "node:assert";
import { nestRectangles } from "./nesting";

const result = nestRectangles(
  [
    { partNo: "A", width: 60, height: 40, quantity: 1 },
    { partNo: "B", width: 40, height: 60, quantity: 1, allowRotation: true },
    { partNo: "C", width: 30, height: 20, quantity: 1 },
  ],
  { width: 100, height: 100, kerf: 2 },
);

assert.equal(result.unplaced.length, 0);
assert.equal(result.sheetCount, 1);
assert.equal(result.placements.length, 3);

for (const placement of result.placements) {
  assert.ok(placement.x >= 0 && placement.y >= 0);
  assert.ok(placement.x + placement.width <= 100);
  assert.ok(placement.y + placement.height <= 100);
}

for (let i = 0; i < result.placements.length; i += 1) {
  for (let j = i + 1; j < result.placements.length; j += 1) {
    const a = result.placements[i];
    const b = result.placements[j];
    const overlap = a.x < b.x + b.width
      && a.x + a.width > b.x
      && a.y < b.y + b.height
      && a.y + a.height > b.y;
    assert.equal(overlap, false);
  }
}

const tooLarge = nestRectangles(
  [{ partNo: "TOO-LARGE", width: 101, height: 10, quantity: 1 }],
  { width: 100, height: 100, kerf: 0 },
);
assert.deepEqual(tooLarge.unplaced, ["TOO-LARGE-1"]);
assert.equal(tooLarge.sheetCount, 0);