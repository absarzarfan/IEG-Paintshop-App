export interface NestInputPart {
  partNo: string;
  width: number;
  height: number;
  quantity: number;
  allowRotation?: boolean;
}

export interface SheetSpec {
  width: number;
  height: number;
  kerf: number;
}

export interface Placement {
  instanceId: string;
  partNo: string;
  sheetIndex: number;
  x: number;
  y: number;
  width: number;
  height: number;
  rotated: boolean;
}

export interface NestResult {
  placements: Placement[];
  unplaced: string[];
  sheetCount: number;
  usedArea: number;
  utilization: number;
}

interface Row {
  y: number;
  height: number;
  usedWidth: number;
}

interface Sheet {
  rows: Row[];
}

function assertFinitePositive(value: number, name: string): void {
  if (!Number.isFinite(value) || value <= 0) throw new Error(`${name} must be positive and finite`);
}

function orientationOptions(
  part: NestInputPart,
  sheet: SheetSpec,
): Array<{ width: number; height: number; rotated: boolean }> {
  const options = [{ width: part.width, height: part.height, rotated: false }];
  if (part.allowRotation !== false && part.width !== part.height) {
    options.push({ width: part.height, height: part.width, rotated: true });
  }
  return options.filter((option) =>
    option.width <= sheet.width && option.height <= sheet.height);
}

function canFitInRow(row: Row, option: { width: number; height: number }, sheet: SheetSpec): boolean {
  const x = row.usedWidth === 0 ? 0 : row.usedWidth + sheet.kerf;
  return option.height <= row.height && x + option.width <= sheet.width;
}

/**
 * Deterministic, feasible shelf nesting for rectangular parts.
 *
 * This is intentionally not an optimizer. It guarantees bounds and non-overlap,
 * while leaving grain, remnant, guillotine, and domain correction policies outside
 * this function.
 */
export function nestRectangles(parts: NestInputPart[], sheet: SheetSpec): NestResult {
  assertFinitePositive(sheet.width, "sheet.width");
  assertFinitePositive(sheet.height, "sheet.height");
  if (!Number.isFinite(sheet.kerf) || sheet.kerf < 0) throw new Error("sheet.kerf cannot be negative");

  const instances = parts.flatMap((part) => {
    assertFinitePositive(part.width, `${part.partNo}.width`);
    assertFinitePositive(part.height, `${part.partNo}.height`);
    if (!Number.isInteger(part.quantity) || part.quantity < 0) {
      throw new Error(`${part.partNo}.quantity must be a non-negative integer`);
    }
    return Array.from({ length: part.quantity }, (_, index) => ({
      ...part,
      instanceId: `${part.partNo}-${index + 1}`,
    }));
  }).sort((a, b) =>
    (b.width * b.height - a.width * a.height)
    || (Math.max(b.width, b.height) - Math.max(a.width, a.height))
    || a.instanceId.localeCompare(b.instanceId));

  const sheets: Sheet[] = [];
  const placements: Placement[] = [];
  const unplaced: string[] = [];

  for (const part of instances) {
    const options = orientationOptions(part, sheet);
    if (options.length === 0) {
      unplaced.push(part.instanceId);
      continue;
    }
    let best:
      | { sheet: Sheet; row: Row; option: (typeof options)[number]; x: number; remainder: number }
      | undefined;

    for (const candidateSheet of sheets) {
      for (const row of candidateSheet.rows) {
        for (const option of options) {
          if (!canFitInRow(row, option, sheet)) continue;
          const x = row.usedWidth === 0 ? 0 : row.usedWidth + sheet.kerf;
          const remainder = sheet.width - (x + option.width);
          if (!best || remainder < best.remainder) {
            best = { sheet: candidateSheet, row, option, x, remainder };
          }
        }
      }
    }

    if (best) {
      best.row.usedWidth = best.x + best.option.width;
      placements.push({
        instanceId: part.instanceId,
        partNo: part.partNo,
        sheetIndex: sheets.indexOf(best.sheet) + 1,
        x: best.x,
        y: best.row.y,
        width: best.option.width,
        height: best.option.height,
        rotated: best.option.rotated,
      });
      continue;
    }

    let newRowPlacement:
      | { target: Sheet; y: number; option: (typeof options)[number] }
      | undefined;
    for (const target of sheets) {
      const last = target.rows[target.rows.length - 1];
      const y = last ? last.y + last.height + sheet.kerf : 0;
      for (const option of options) {
        if (y + option.height <= sheet.height) {
          newRowPlacement = { target, y, option };
          break;
        }
      }
      if (newRowPlacement) break;
    }

    if (!newRowPlacement) {
      const target: Sheet = { rows: [] };
      sheets.push(target);
      const option = options[0];
      newRowPlacement = { target, y: 0, option };
    }

    const row: Row = {
      y: newRowPlacement.y,
      height: newRowPlacement.option.height,
      usedWidth: newRowPlacement.option.width,
    };
    newRowPlacement.target.rows.push(row);
    placements.push({
      instanceId: part.instanceId,
      partNo: part.partNo,
      sheetIndex: sheets.indexOf(newRowPlacement.target) + 1,
      x: 0,
      y: row.y,
      width: newRowPlacement.option.width,
      height: newRowPlacement.option.height,
      rotated: newRowPlacement.option.rotated,
    });
  }

  const usedArea = placements.reduce((sum, placement) => sum + placement.width * placement.height, 0);
  const totalArea = sheets.length * sheet.width * sheet.height;
  return {
    placements,
    unplaced,
    sheetCount: sheets.length,
    usedArea,
    utilization: totalArea === 0 ? 0 : usedArea / totalArea,
  };
}