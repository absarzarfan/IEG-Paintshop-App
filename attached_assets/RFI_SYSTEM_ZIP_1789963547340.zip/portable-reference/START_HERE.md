# Portable Reference Package

## Tujuan

Package ini adalah acuan untuk membangun project baru dengan workflow operasional yang
mirip RFI Workflow System, tetapi dengan nama produk, fungsi bisnis, department, dan
terminologi yang berbeda.

## Hal paling penting

Project sumber yang dianalisis adalah **workflow request / inspection**, bukan sistem
material planning atau nesting/cutting. Karena itu:

- aturan workflow, role, timer, handover, rework, review, attachment, report period,
  dan timezone berasal dari implementasi nyata;
- tidak ada algoritma nesting produksi, part-list planner, kerf optimizer, atau aturan
  “3-sheet vs 2-sheet correction” yang dapat diekstrak secara jujur;
- `source/frontend/nesting.ts` adalah **reference implementation generik** yang sengaja
  berdiri sendiri. Ia bukan bukti bahwa algoritma tersebut pernah dipakai project sumber;
- jangan mengaktifkan koreksi 3-sheet/2-sheet tanpa formula dan contoh bisnis yang
  disetujui pemilik proses.

## Urutan membaca

1. `BUSINESS_RULES.md` — aturan yang harus dipertahankan atau dikonfirmasi ulang.
2. `DATA_MODEL.md` — entitas, lifecycle, dan bentuk data.
3. `NESTING_ALGORITHM.md` — batas antara logic sumber dan reference nesting.
4. `AI_BUILD_BRIEF.md` — prompt siap-copy untuk coding assistant.
5. `PORTING_CHECKLIST.md` — langkah adaptasi sebelum implementasi.
6. `contracts/openapi.yaml` dan `database/` — contoh interface dan persistence.

## Label adaptasi

- **COPY DIRECTLY**: logic portable dan tidak bergantung pada nama project.
- **ADAPT**: harus diubah untuk nama fungsi, department, status, role, atau policy baru.
- **VERIFY**: perilaku berasal dari source tetapi perlu dikonfirmasi kepada owner proses.
- **DO NOT ASSUME**: tidak ada bukti implementasi di project sumber.

## Isi package

```text
source/shared/types.ts                 COPY DIRECTLY, lalu perluas sesuai domain
source/backend/workflowPolicy.ts       COPY DIRECTLY sebagai pure workflow policy
source/backend/timeAndShift.ts         ADAPT timezone dan shift
source/backend/attachmentPolicy.ts     COPY DIRECTLY jika batas file sama
source/backend/partList.ts             REFERENCE untuk domain material baru
source/frontend/nesting.ts             REFERENCE generic rectangle nesting
contracts/openapi.yaml                 ADAPT route/schema/role names
database/001_rfi_state.sql             REFERENCE legacy JSONB persistence
database/002_normalized_workflow.sql   REFERENCE normalized persistence
```

## Yang tidak boleh dipindahkan

- `password`, token, session secret, bucket ID, URL deployment, atau environment file;
- seed user dan data operasional;
- generated client, compiled `dist`, source map, `node_modules`, dan build cache;
- brand/logo/nama department dari source;
- asumsi bahwa nesting reference adalah optimizer optimal atau hasil historis source.

## Kontrak kualitas

Sebelum project baru dianggap benar, minimal harus ada test untuk:

1. create → queue → start → pause/resume/handover → complete;
2. QC `Pass` menutup job;
3. QC `Reject` menambah rework cycle dan membuat job dapat di-resubmit;
4. resubmit mempertahankan identity, history, notes, attachments, dan cumulative
   rework count;
5. requestor tidak dapat memutasi job milik user lain;
6. inspector tidak dapat menjalankan dua active inspection sekaligus;
7. elapsed time tidak reset saat pause/handover/rework;
8. attachment limit dan upload authorization;
9. report period menggunakan timezone bisnis;
10. nesting tidak menghasilkan rectangle overlap dan tidak melebihi batas sheet.